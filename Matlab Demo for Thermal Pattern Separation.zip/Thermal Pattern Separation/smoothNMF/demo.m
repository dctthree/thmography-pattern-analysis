%%% Load audio data %%%

disp('Loading data...')

addpath ./stft/
[x,fs,n_bits] = wavread('data.wav');
x=x.';
T = length(x);
l_win = 256;
overlap = l_win/2;
X = cf_stft(x,l_win,overlap);
V = abs(X).^2;
[F,N] = size(V);

%%% Algo parameters and init %%%
K = 10;
W_ini = abs(randn(F,K)) + ones(F,K);
H_ini = abs(randn(K,N)) + ones(K,N);

n_iter = 100;
% WARNING
% The number of iterations is here set to low value to fasten the execution
% of this demo but should be increased to at least 1000 to produce sensible
% results
disp('In this demo the nb of iterations is set to 100. Set it to about 1000 for better results.')


lambda = 25;

%%% Run algos %%%
disp('Running smooth IS-NMF...')
[W_sm, H_sm, cost_sm, cost_pen_sm] = nmf_is_smooth(V, n_iter, W_ini, H_ini, lambda);

disp('Running unpenalized IS-NMF for comparison...')
[W_is, H_is, cost_is] = nmf_is(V, n_iter, W_ini, H_ini);

%%% Plot cost functions %%%

semilogy(1:n_iter,cost_is,'b',1:n_iter,cost_sm,'r');
title('IS cost function')
legend('unpenalized','penalized')


%%% Reconstruct components with Wiener filtering %%%

Tpad = l_win + (N-1)*(l_win-overlap);
c_is = zeros(K,Tpad);
c_sm = zeros(K,Tpad);

V_is = W_is*H_is;
V_sm = W_sm*H_sm;

for k=1:K
    c_is(k,:) = real(cf_istft(((W_is(:,k)*H_is(k,:))./V_is).*X ,l_win,overlap));
    c_sm(k,:) = real(cf_istft(((W_sm(:,k)*H_sm(k,:))./V_sm).*X ,l_win,overlap));
end
c_is = c_is(:,overlap+1:overlap+T);
c_sm = c_sm(:,overlap+1:overlap+T);

%%% Produce .wav files %%%
for k = 1:K
    wavwrite(c_is(k,:),fs,n_bits,['is-' num2str(k)]) ;
    wavwrite(c_sm(k,:),fs,n_bits,['sm-' num2str(k)]) ;
end

disp('Display results...')
disp('WAV files of separated components ready in current directory.')
disp('is-*.wav = unpenalized IS-NMF')
disp('sm-*.wav = smooth IS-NMF')
