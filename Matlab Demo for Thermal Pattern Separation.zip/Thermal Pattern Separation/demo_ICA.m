% The code is running by using RMatlab 2015b
% If you use this code please cite this paper
%
% Bin Gao, Libing Bai, Gui Yun Tian, W.L. Woo, Yuhua Cheng ��Automatic Defect Identifcation of Eddy Current Pulsed Thermography Using Single Channel Blind Source Separation�� IEEE
% Transactions on Instrumentation and Measurement, vol.63, no.4, pp.913-922. 2014.
% Bin Gao, W.L. Woo, Guiyun Tian. ��Electromagnetic Thermography Nondestructive Evaluation: Physics based Modeling and Pattern Mining��, Sci. Rep. 6, 25480; doi: 10.1038/srep25480 (2016).
% and
% Bin Gao, Libing Bai, W. L. Woo, and Guiyun Tian, ��Thermography pattern analysis and separation��, Applied Physics Letters 104, 251902 (2014); doi: 10.1063/1.4884644, 5 pages, 2014.
% Copyright 2014  Bin Gao
% This software is distributed under the terms of the GNU Public License
% version 3 (http://www.gnu.org/licenses/gpl.txt)
% Report bugs to Bin Gao
% bin_gao -at- uestc.edu.cn
% Checked 2/12/14

load data % Loading the inductive thermography data (as for inductive thermography, 
          % the early stage is sufficient for analyzing the defect pattern,
          % e.g. in order to save space, we only take the first 20 frames for this demo which is
          % differ from the paper that takes the whole vedio for processing
addpath ./FastICA_25
[F,N,T]=size(data);
noc=4; % Setting the number of thermal patterns (dependent on the specific applications)

%Convert data (tensor) to matrix form
for i=1:T
    data_temp=data(:,:,i);
    X(:,i)=data_temp(:);
end

% Use independent component analysis to separate the thermal patterns (This 
% also can be achieved by other algorithms such as nonnegative matrix factorization and sparse 
% factorization and etc where it is dependent on the applications

[ICA,A,W] = fastica (X', 'lastEig', noc, 'numOfIC', noc);% Use fastICA software
 k = kurtosis(ICA');%use kurtosis to find the re-order the components
    [B ind]= sort(k);
    for j = 1:size(ICA,1)
        comp(:,j) = ICA(ind(j),:)';
        A_update(:,j)=A(:,ind(j));
        W_update(:,j)=W(ind(j),:);
        kurt_ICA(j)=k(ind(j));
    end

% Plot the thermal patterns where the largest kurtosis value indicates the
% defect relevant ICA component
for i=1:size(comp,2)
    figure
    imagesc(reshape(comp(:,i),F,N));%or imagesc(reshape(ICA(i,:)*-1,F,N)) 
    set(gca,'fontsize',18);
    xlabel('Spatial x axis','fontsize',18)
    ylabel('Spatial y axis','fontsize',18)
    title('Thermal Patterns','fontsize',18);
    axis xy    
end
% Plot the transient patterns where for simplycation we only take the first
% 20 frame (heating time)
for i=1:size(A_update,2)
    figure
    plot(A_update(:,i));%or imagesc(reshape(ICA(i,:)*-1,F,N)) 
    set(gca,'fontsize',18);
    xlabel('Frames','fontsize',18)
    ylabel('DL','fontsize',18)
    title('Transient Patterns','fontsize',18);   
end
% One separated thermal patterns with emphasis of hot spots is used for
% defect detection in NDT&E